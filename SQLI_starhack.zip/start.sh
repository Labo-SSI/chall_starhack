#!/bin/bash

print_color() {
    local color=$1
    shift
    echo -e "\e[${color}m$@\e[0m"
}

check_status() {
    local command_name=$1
    local exit_code=$2
    if [[ $exit_code -ne 0 ]]; then
        print_color "31" "Failed to $command_name\n"
        exit 1
    fi
}

print_color "33" "######### CHECKING DOCKER ##########\n"

docker_version=$(docker --version 2>&1)
if [[ $? -ne 0 ]]; then
    
    print_color "31" "Docker not installed, installing it now ...\n"
    # Install Docker
    sudo apt update
    sudo apt install -y docker.io
    # Verify installation
    check_status "install Docker" $?
    print_color "32" "Docker installed successfully"\n
else
    print_color "32" "Docker is installed\n"
fi


print_color "33" "######### CHECKING DOCKER-COMPOSE ##########\n"

# Check if Docker Compose is installed
docker_compose_version=$(docker-compose --version 2>&1)
if [[ $? -ne 0 ]]; then
    print_color "31" "Docker Compose not installed, installing it now ...\n"
    # Install Docker Compose
    sudo apt install -y docker-compose
    # Verify installation
    check_status "install Docker Compose" $?
    print_color "32" "Docker Compose installed successfully\n"
else
    print_color "32" "Docker Compose is installed\n"
fi


print_color "32" "Installation completed\n"

print_color "33" "######### DEPLOYING THE APPLICATION ##########\n"

sudo docker-compose build
check_status "build the application" $?
sudo docker-compose up -d
check_status "deploy the application" $?
print_color "32" "Application deployed successfully"
