const express = require("express");
const cookieParser = require("cookie-parser");
const jwt = require("jsonwebtoken");
const mysql = require("mysql");
var cors = require("cors");
require("dotenv").config();
var path = require("path");
const app = express();
const PORT = process.env.PORT || 5000;
const bodyParser = require("body-parser");

// Setting up my view Engine
app.set("views", path.join(__dirname, "views"));
app.set("view engine", "ejs");
app.use("/static", express.static(path.join(__dirname, "static")));

//Setting up my middlewares
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
const { login, register } = require("./middlewares/m_auth.js");
app.use(bodyParser.urlencoded({ extended: true }));

const connection = mysql.createConnection({
  host: process.env.DB_HOST || 'db',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || 'pass',
  database: process.env.DB_NAME || 'competition_db',
  port: 3306,
});
connection.connect((err) => {
  if (err) {
    console.error("Error connecting to MySQL database: " + err.stack);
    return;
  }
  console.log("Connected to MySQL database as id " + connection.threadId);
});

const secretKey = "competition_secret_key";

app.get("", async (req, res) => {
  try {
    const token = req.cookies.token ? req.cookies.token : null;
    if (!token) {
      return res.status(200).render("login");
    }
    jwt.verify(token, secretKey, (err, decoded) => {
      if (err) {
        return res.status(401).render("login");
      }

      const query = "SELECT * FROM support_tickets";
      connection.query(query, (err, results) => {
        if (err) {
          console.error("Error fetching ticket:", err);
          return res.status(500).send("Error fetching ticket");
        }
        res.render("home", { tickets: results });
      });
    });
  } catch (error) {
    console.error("Error retrieving user tickets:", error);
    return res.status(500).send("Error retrieving tickets");
  }
});

app.get("/login", (req, res) => {
  try {
    const token = req.cookies.session;
    if (token) {
      return res.redirect("/");
    } else {
      return res.render("login");
    }
  } catch (err) {
    res.render("login");
  }
});

app.get("/register", (req, res) => {
  try {
    const token = req.cookies.session;
    if (token) {
      return res.redirect("/");
    } else {
      return res.render("register", { error: "" });
    }
  } catch (err) {
    res.render("login");
  }
});

app.post("/login", login);
app.post("/register", register);

app.get("/support", (req, res) => {
  try {
    const blacklist = [",", "=", "UNION", "union", "SELECT", "select", "FROM", "from"];
    const { type } = req.query;
    const token = req.cookies.token ? req.cookies.token : null;

    if (!token) {
      return res.status(200).render("login");
    }

    jwt.verify(token, secretKey, (err, decoded) => {
      if (err) {
        return res.status(401).render("login");
      }

      if (type) {
        let cleanType = decodeURIComponent(type);

        const containsBlacklistedWord = blacklist.some((word) => cleanType.includes(word));
        const isValidType = /^[a-zA-Z0-9'()* \-]+$/g.test(cleanType);

        if (containsBlacklistedWord || !isValidType) {
          return res.status(400).json({
            error: "Bad input was detected. Stopping processing the request.",
          });
        }

        const query = `SELECT * FROM support_tickets WHERE type = '${cleanType}'`;
        connection.query(query, (err, rows) => {
          if (err) {
            console.error("Error fetching support tickets: ", err);
            return res.json({ Error: "An Error Occurred during handling your request." });
          }
          return res.render("home", { tickets: rows });
        });
      } else {
        return res.render("support");
      }
    });
  } catch (err) {
    console.error("Error in /support route: ", err);
    return res.status(500).send({ Error: "An error occurred while handling your request." });
  }
});


app.use((req, res, next) => {
  res.status(404).send("Sorry, the page you're looking for doesn't exist.");
});

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
``
